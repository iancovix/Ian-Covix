// api/server.js
import {apiKey as api_Key} from './api.js';
export default async function handler(req, res) {
  const apiKey = `${api_Key}`; // get key from environment variable

  const response = await fetch(
    `https://newsapi.org/v2/top-headlines?country=us&apiKey=${apiKey}`
  );
  const data = await response.json();

  // Fix CORS (allow all domains — or you can set your own domain instead of '*')
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Methods", "GET");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type");

  return res.status(200).json(data);
}